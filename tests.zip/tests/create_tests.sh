#!/bin/bash

for i in {4..10}; do
	touch test${i}.IPPcode22;
done
