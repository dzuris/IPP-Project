#!/bin/bash

for i in {2..10}; do
	touch testHead${i}.IPPcode22;
done
